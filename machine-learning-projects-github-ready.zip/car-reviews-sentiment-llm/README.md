# Analyzing Car Reviews with LLMs

Prototype for a car sales and rental company chatbot. A pre-trained Hugging Face model classifies the sentiment of customer car reviews, and the predictions are evaluated with accuracy and F1 score.

## What it does
1. Loads a small set of car reviews with labeled sentiment
2. Classifies each review using `distilbert-base-uncased-finetuned-sst-2-english`
3. Maps predicted labels to binary values (1 positive, 0 negative)
4. Evaluates predictions with the `evaluate` library (accuracy and F1)

## Tech stack
Python, pandas, Hugging Face Transformers, evaluate, PyTorch

## Run it
```bash
pip install pandas transformers evaluate torch scikit-learn
jupyter notebook Analyzing_car_reviews_with_LLMs.ipynb
```
